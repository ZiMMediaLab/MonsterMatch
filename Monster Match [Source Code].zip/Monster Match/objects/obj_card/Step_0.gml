/// @description Show the correct sprite
if ( face == 0 )
{
	sprite_index = spr_cardback;
}
else
{
	switch(type)
	{
		case 0:
			sprite_index = spr_bigfootcard;
			break;
		case 1:
			sprite_index = spr_draculacard;
			break;
		case 2:
			sprite_index = spr_frankcard;
			break;
		case 3:
			sprite_index = spr_mummycard;
			break;
		case 4:
			sprite_index = spr_mermancard;
			break;
		case 5:
			sprite_index = spr_cyclopscard;
			break;
		case 6:
			sprite_index = spr_demoncard;
			break;
		case 7:
			sprite_index = spr_aliencard;
			break;
		case 8:
			sprite_index = spr_robotcard;
			break;
		case 9:
			sprite_index = spr_skellycard;
			break;
		case 10:
			sprite_index = spr_wolfmancard;
			break;
		case 11:
			sprite_index = spr_zombiecard;
			break;
		default:
			break;
	}
}

var flipping = true;

/// Step Event
if (global.game_state == STATES.PLAYING) {
    if (mouse_check_button_pressed(mb_left)) {
        if (!flipping) {
            face = 1;
            global.cards_picked += 1;

            if (global.cards_picked > 1) {
                obj_controller.card_sel_2 = id;
                global.game_state = STATES.PAUSED;

                if (obj_controller.card_sel_1.index == obj_controller.card_sel_2.index) {
                    face = 0;
                    reset_selection(obj_controller.deck);
                    global.game_state = STATES.PLAYING;
                } else {
                    alarm[0] = 0.5 * 60;
                }
            } else {
                obj_controller.card_sel_1 = id;
            }
            flipping = true;
        }
    }
}

/// Alarm Event
if (alarm[0] == 0) {
    flipping = false;
}

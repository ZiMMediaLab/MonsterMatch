/// @description Trigger You Lost Screen
cur_time = 0;
audio_stop_sound(snd_game_music);
global.game_state = STATES.LOST;


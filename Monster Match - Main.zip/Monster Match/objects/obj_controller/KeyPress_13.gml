/// @description Shuffle deck
shuffle_cards(deck);
alarm[0] = play_time * 60;
audio_stop_sound(snd_game_music);
audio_stop_sound(snd_evil_laugh);
audio_play_sound(snd_game_music, 0, false);
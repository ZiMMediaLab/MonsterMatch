/// @description Game Over checks


cur_time = 0;

if (check_victory(deck))
	{
		global.game_state = STATES.WON;
	}
else
	{
		audio_play_sound(snd_evil_laugh, 0, false);
		global.game_state = STATES.LOST;
	
		 // Show ALL remaining cards.
		for (var i = 0; i < ds_list_size(deck); i++)
		{
			deck[| i].face = 1; 
		}
	}



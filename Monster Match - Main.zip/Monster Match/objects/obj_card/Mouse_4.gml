/// @description Pick a card
if (visible and global.game_state == STATES.PLAYING) // if we are playing
{
    face = 1;
    global.cards_picked += 1;

    var card_selected = false; // Flag to track if a card is selected

    // Check mouse input
    if (mouse_check_button_pressed(mb_left)) {
        card_selected = true;
    }

    // If no mouse button was pressed, check for touch input
    if (!card_selected && device_get_num_touch_devices() > 0) {
        for (var i = 0; i < device_get_num_touch_points(); i++) {
            if (device_get_touch_state(i) == true && device_get_touch_x(i) >= x && device_get_touch_x(i) <= x + sprite_width && device_get_touch_y(i) >= y && device_get_touch_y(i) <= y + sprite_height) {
                card_selected = true;
                break; // exit loop after detecting touch input for one touch point
            }
        }
    }

    // If a card is selected
    if (card_selected) {
        if (global.cards_picked > 1) // one card already selected
        {
			audio_play_sound(snd_card_flip, 0, false);
            obj_controller.card_sel_2 = self;
            global.game_state = STATES.PAUSED;

            if (obj_controller.card_sel_1.index == obj_controller.card_sel_2.index) // if you selected two times the same card
            {
                face = 0;
                reset_selection(obj_controller.deck);
                global.game_state = STATES.PLAYING;
            }
            else // if cards are different, check if they are equal or not with a 0.5 delay (to show the pair a bit before flipping/disappearing) 
            {
                alarm[0] = 0.5 * 60;
            }
        }
        else
        {
			audio_play_sound(snd_card_flip, 0, false);
            obj_controller.card_sel_1 = self;
        }
    }
}

/// @description Start Game

// obj_start_menu Left Pressed Event (for mouse click)
if (mouse_check_button_pressed(mb_left)) // Check if left mouse button is pressed
{
    room_goto(rm_game); // Switch to the game room (replace "rm_game" with your actual game room name)
}
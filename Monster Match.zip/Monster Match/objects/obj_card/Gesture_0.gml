/// @description Touch Screen / Pick a Card.

var flipping = true;

/// Step Event
if (global.game_state == STATES.PLAYING) {
    if (gesture.tap())
		{
        if (!flipping) 
		{
            face = 1;
            global.cards_picked += 1;

            if (global.cards_picked > 1) {
                obj_controller.card_sel_2 = id;
                global.game_state = STATES.PAUSED;

                if (obj_controller.card_sel_1.index == obj_controller.card_sel_2.index) {
                    face = 0;
                    reset_selection(obj_controller.deck);
                    global.game_state = STATES.PLAYING;
                } else {
                    alarm[0] = 0.5 * 60;
                }
            } else {
                obj_controller.card_sel_1 = id;
            }
            flipping = true;
        }
    }
}

/// Alarm Event
if (alarm[0] == 0) {
    flipping = false;
}

/// @description Show the correct sprite
if ( face == 0 )
{
	sprite_index = spr_cardback;
}
else
{
	switch(type)
	{
		case 0:
			sprite_index = spr_bigfootcard;
			break;
		case 1:
			sprite_index = spr_draculacard;
			break;
		case 2:
			sprite_index = spr_frankcard;
			break;
		case 3:
			sprite_index = spr_mummycard;
			break;
		case 4:
			sprite_index = spr_mermancard;
			break;
		case 5:
			sprite_index = spr_cyclopscard;
			break;
		case 6:
			sprite_index = spr_demoncard;
			break;
		case 7:
			sprite_index = spr_aliencard;
			break;
		case 8:
			sprite_index = spr_robotcard;
			break;
		case 9:
			sprite_index = spr_skellycard;
			break;
		case 10:
			sprite_index = spr_wolfmancard;
			break;
		case 11:
			sprite_index = spr_zombiecard;
			break;
		default:
			break;
	}
}



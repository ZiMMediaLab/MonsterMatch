/// @description Initialize card
index = noone;
type = noone;
face = 1;
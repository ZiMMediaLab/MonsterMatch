/// @description draw UI

var shadow_offset_x = 0;
var shadow_offset_y = 0;


switch(global.game_state)
{
	case STATES.PLAYING: // playing
		cur_time = ceil(alarm[0]/60);
		break;

	case STATES.WON: // won
		alarm[0] = -1;
		draw_set_font(fnt_shadow_big); // Use your shadow font
		draw_set_color(c_black); // Shadow color
		draw_text(300 + shadow_offset_x, 350 + shadow_offset_y, "YOU WON!");

		draw_set_font(fnt_state);
		draw_set_color(c_red);
		draw_text(300, 350, "YOU WON!");
		break;

	case STATES.LOST: // lost
		alarm[0] = -1;
		draw_set_font(fnt_shadow_big); // Use your shadow font
		draw_set_color(c_black); // Shadow color
		draw_text(300 + shadow_offset_x, 350 + shadow_offset_y, "YOU LOST!");
		
		draw_set_font(fnt_state);
		draw_set_color(c_red);
		draw_text(300 + shadow_offset_x, 350 + shadow_offset_y, "YOU LOST!");
		break;

	default:
		break;
}

draw_set_font(fnt_shadow); // Use your shadow font
draw_set_color(c_black); // Shadow color
draw_text(320 + shadow_offset_x, 13 + shadow_offset_y, "Time Left: " + string(cur_time));

draw_set_font(fnt_timer);
draw_set_color(c_white);
draw_text(320, 13, "Time Left: " + string(cur_time));

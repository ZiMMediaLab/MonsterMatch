/// @description Exit Button

if (mouse_check_button_pressed(mb_left)) // Check if left mouse button is pressed
{
    game_end(); // This function exits the game
}

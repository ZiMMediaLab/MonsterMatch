/// @description Exit Game

if (mouse_check_button_pressed(mb_left))
	{
		game_end();
	}